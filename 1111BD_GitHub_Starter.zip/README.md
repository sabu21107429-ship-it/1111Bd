# 1111BD Starter

A starter project for the 1111BD website. This is a development scaffold, not a live service.

## Included
- Express backend
- Health-check endpoint
- PostgreSQL schema for users, virtual-coin wallets, and ledger entries
- Environment-variable example

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set your own values.
4. Run `npm start`.

No real-money betting, payment processing, wallet PIN/OTP collection, or external wallet balance access is included.
