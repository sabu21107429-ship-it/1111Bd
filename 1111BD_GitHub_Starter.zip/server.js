require("dotenv").config();
const express = require("express");
const { Pool } = require("pg");

const app = express();
app.use(express.json());

const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } })
  : null;

app.get("/", (_req, res) => {
  res.json({ app: "1111BD", status: "starter", message: "Backend is running" });
});

app.get("/health", async (_req, res) => {
  try {
    if (pool) await pool.query("SELECT 1");
    res.json({ ok: true, databaseConfigured: Boolean(pool) });
  } catch (_err) {
    res.status(503).json({ ok: false, databaseConfigured: true });
  }
});

app.get("/api/games", (_req, res) => {
  res.json([
    { id: "memory", name: "Memory Match", type: "demo", realMoney: false },
    { id: "number-puzzle", name: "Number Puzzle", type: "demo", realMoney: false }
  ]);
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`1111BD server listening on ${port}`));
